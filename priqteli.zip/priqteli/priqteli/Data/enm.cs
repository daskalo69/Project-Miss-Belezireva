﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace priqteli.Data
{
    public enum TypeFood {Food,Domestic,Health,Cosmetic,Other }
  
}
